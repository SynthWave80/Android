package com.example.clientapp;



import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class MyAdapter extends ArrayAdapter<Seance> {

    Context context;
    List<Seance> arrayListSeance;



    public MyAdapter(@NonNull Context context, List<Seance> arrayListSeance) {
        super(context, R.layout.custom_list_item, arrayListSeance);

        this.context = context;
        this.arrayListSeance = arrayListSeance;

    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_list_item,null,true);


        TextView tvDate = view.findViewById(R.id.txt_date);
        TextView tvDebut = view.findViewById(R.id.txt_debut);
        TextView tvFin = view.findViewById(R.id.txt_fin);
        TextView tvClient = view.findViewById(R.id.txt_idclient);


        tvDate.setText(arrayListSeance.get(position).getDateSeance());
        tvDebut.setText(arrayListSeance.get(position).getHeureDebut());
        tvFin.setText(arrayListSeance.get(position).getHeureFin());
        tvClient.setText(String.valueOf(arrayListSeance.get(position).getId_Client()));


        return view;
    }
}
