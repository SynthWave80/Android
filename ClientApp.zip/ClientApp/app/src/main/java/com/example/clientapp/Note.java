package com.example.clientapp;

public class Note {
    private int id_Note;
    private String dateNote;
    private String Description;
    private String Content_Note;
    private int id_Client;

    public Note() {
    }

    public Note(int id_Note, String dateNote, String description, String Content_Note, int id_Client) {
        this.id_Note = id_Note;
        this.dateNote = dateNote;
        this.Description = description;
        this.id_Client = id_Client;
    }

    public int getId_Note() {
        return id_Note;
    }

    public void setId_Note(int id_Tache) {
        this.id_Note = id_Note;
    }

    public String getDateNote() {
        return dateNote;
    }

    public void setDateNote(String dateTache) {
        this.dateNote = dateNote;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        this.Description = description;
    }

    public int getId_Client() {
        return id_Client;
    }

    public void setId_Client(int id_Client) {
        this.id_Client = id_Client;
    }
}
