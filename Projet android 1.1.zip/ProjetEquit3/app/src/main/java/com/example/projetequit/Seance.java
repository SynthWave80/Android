package com.example.projetequit;

public class Seance {

    String dateSeance, heureDebut, heureFin;
    int id_Client, id_Moniteur;




}
