package com.example.adminapp;

public class Seance {
    private int id_Seance;
    private String dateSeance;
    private String heureDebut;
    private String heureFin;
    private int id_Client;
    private int id_Moniteur;


    public Seance() {
    }

    public Seance(int id_Seance, String dateSeance, String heureDebut, String heureFin, int id_Client, int id_Moniteur) {
        this.id_Seance = id_Seance;
        this.dateSeance = dateSeance;
        this.heureDebut = heureDebut;
        this.heureFin = heureFin;
        this.id_Client = id_Client;
        this.id_Moniteur = id_Moniteur;
    }

    public int getId_Seance() {
        return id_Seance;
    }

    public void setId_Seance(int id_Seance) {
        this.id_Seance = id_Seance;
    }

    public String getDateSeance() {
        return dateSeance;
    }

    public void setDateSeance(String dateSeance) {
        this.dateSeance = dateSeance;
    }

    public String getHeureDebut() {
        return heureDebut;
    }

    public void setHeureDebut(String heureDebut) {
        this.heureDebut = heureDebut;
    }

    public String getHeureFin() {
        return heureFin;
    }

    public void setHeureFin(String heureFin) {
        this.heureFin = heureFin;
    }

    public int getId_Client() {
        return id_Client;
    }

    public void setId_Client(int id_Client) {
        this.id_Client = id_Client;
    }

    public int getId_Moniteur() {
        return id_Moniteur;
    }

    public void setId_Moniteur(int id_Moniteur) {
        this.id_Moniteur = id_Moniteur;
    }
}
