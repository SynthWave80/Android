package com.example.adminapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class SeancesActivity extends AppCompatActivity {

    ListView listView;
    MyAdapter adapter;
    public static ArrayList<Seance> seanceArrayList = new ArrayList<>();
    String url = "https://pbe.diamond-montres.com/android/GetSeances.php";
    Seance seance;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seances);

        listView = findViewById(R.id.myListView);
        adapter = new MyAdapter(this,seanceArrayList);
        listView.setAdapter(adapter);

        GetSeances();

    }

    public void GetSeances() {

        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        seanceArrayList.clear();
                        try{
                            JSONObject jsonObject = new JSONObject(response);
                            String success = jsonObject.getString("success");
                            JSONArray jsonArray = jsonObject.getJSONArray("data");

                            if(success.equals("1")) {

                                for(int i=0; i<jsonArray.length();i++) {
                                    JSONObject object = jsonArray.getJSONObject(i);

                                    int id = object.getInt("id");
                                    String dateseance = object.getString("date");
                                    String heuredebut = object.getString("heuredebut");
                                    String heurefin = object.getString("heurefin");
                                    int idclient = object.getInt("idclient");
                                    int idmoniteur = object.getInt("idmoniteur");

                                    seance = new Seance(id, dateseance, heuredebut, heurefin, idclient, idmoniteur);
                                    seanceArrayList.add(seance);
                                    adapter.notifyDataSetChanged();
                                }

                            }

                        }
                        catch(JSONException e) {
                            e.printStackTrace();
                        }



                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(SeancesActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(SeancesActivity.this);
        requestQueue.add(request);

    }

    public void Back(View view) {
        startActivity(new Intent(getApplicationContext(), AdminDashboardActivity.class));
        finish();
    }

    public void ToAddSeance(View view) {
        startActivity(new Intent(getApplicationContext(), AddSeanceActivity.class));
        finish();
    }




}