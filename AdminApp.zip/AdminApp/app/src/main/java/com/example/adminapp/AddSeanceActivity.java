package com.example.adminapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class AddSeanceActivity extends AppCompatActivity {

    EditText etDateSeance;
    EditText etHeureDebut;
    EditText etHeureFin;
    EditText etClient;
    EditText etMoniteur;
    String str_dateseance,str_heuredebut, str_heurefin, str_client, str_moniteur;
    String url = "https://pbe.diamond-montres.com/android/AddSeance.php";
    String urlcheck = "https://pbe.diamond-montres.com/android/CheckClientMoniteur.php";

    public void BackToSeances(View view) {
        startActivity(new Intent(getApplicationContext(), SeancesActivity.class));
        finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_seance);


        etDateSeance = findViewById(R.id.etDateSeance);
        etHeureDebut = findViewById(R.id.etHeureDebut);
        etHeureFin = findViewById(R.id.etHeureFin);
        etClient = findViewById(R.id.etClient);
        etMoniteur = findViewById(R.id.etMoniteur);



    }


    public void AddSeance(View view) {

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait..");


        if(etDateSeance.getText().toString().equals("")){
            Toast.makeText(this, "Veuillez choisir la date de la séance", Toast.LENGTH_SHORT).show();
        }
        else if(!etDateSeance.getText().toString().matches("^\\d{2}/\\d{2}/\\d{4}$")){
            Toast.makeText(this, "Date invalide", Toast.LENGTH_SHORT).show();
        }
        else if(etHeureDebut.getText().toString().equals("")){
            Toast.makeText(this, "Veuillez choisir l'heure de début de la séance", Toast.LENGTH_SHORT).show();
        }
        else if(!etHeureDebut.getText().toString().matches("^\\d{2}:\\d{2}$")){
            Toast.makeText(this, "Heure de début invalide", Toast.LENGTH_SHORT).show();
        }
        else if(etHeureFin.getText().toString().equals("")){
            Toast.makeText(this, "Veuillez choisir l'heure de fin de la séance", Toast.LENGTH_SHORT).show();
        }
        else if(!etHeureFin.getText().toString().matches("^\\d{2}:\\d{2}$")){
            Toast.makeText(this, "Heure de fin invalide", Toast.LENGTH_SHORT).show();
        }
        else if(etClient.getText().toString().equals("")){
            Toast.makeText(this, "Veuillez choisir le client", Toast.LENGTH_SHORT).show();
        }
        else if(etMoniteur.getText().toString().equals("")){
            Toast.makeText(this, "Veuillez choisir le moniteur", Toast.LENGTH_SHORT).show();
        }

        else {

            progressDialog.show();
            str_dateseance = etDateSeance.getText().toString().trim();
            str_heuredebut = etHeureDebut.getText().toString().trim();
            str_heurefin = etHeureFin.getText().toString().trim();
            str_client = etClient.getText().toString().trim();
            str_moniteur = etMoniteur.getText().toString().trim();


            StringRequest requestcheck = new StringRequest(Request.Method.POST, urlcheck, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    progressDialog.dismiss();


                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        String success = jsonObject.getString("success");

                        if (success.equalsIgnoreCase("false")) {

                            Toast.makeText(AddSeanceActivity.this, "Client ou moniteur n'existe pas", Toast.LENGTH_SHORT).show();
                        }

                        else {


                            StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    progressDialog.dismiss();
                                    etDateSeance.setText("");
                                    etHeureDebut.setText("");
                                    etHeureFin.setText("");
                                    etClient.setText("");
                                    etMoniteur.setText("");
                                    Toast.makeText(AddSeanceActivity.this, "Séance ajoutée avec succès", Toast.LENGTH_SHORT).show();

                                    startActivity(new Intent(getApplicationContext(), AddSeanceActivity.class));
                                    finish();

                                }
                            },new Response.ErrorListener(){

                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    progressDialog.dismiss();
                                    Toast.makeText(AddSeanceActivity.this, "here 1", Toast.LENGTH_SHORT).show();
                                }
                            }

                            ){
                                @Override
                                protected Map<String, String> getParams() throws AuthFailureError {
                                    Map<String,String> params = new HashMap<String, String>();

                                    params.put("dateseance",str_dateseance);
                                    params.put("heuredebut",str_heuredebut);
                                    params.put("heurefin",str_heurefin);
                                    params.put("idclient",str_client);
                                    params.put("idmoniteur",str_moniteur);
                                    return params;

                                }
                            };

                            RequestQueue requestQueue = Volley.newRequestQueue(AddSeanceActivity.this);
                            requestQueue.add(request);


                        }

                    } catch (JSONException e) {
                        Toast.makeText(AddSeanceActivity.this, "here 2", Toast.LENGTH_SHORT).show();
                        e.printStackTrace();
                    }

                }
            }, new Response.ErrorListener() {

                @Override
                public void onErrorResponse(VolleyError error) {
                    progressDialog.dismiss();
                    Toast.makeText(AddSeanceActivity.this, "here 3", Toast.LENGTH_SHORT).show();
                }
            }

            ) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("idclient", str_client);
                    params.put("idmoniteur", str_moniteur);
                    return params;

                }
            };

            RequestQueue requestQueue = Volley.newRequestQueue(AddSeanceActivity.this);
            requestQueue.add(requestcheck);



        }

    }
}