package com.example.adminapp;

public class User {

    String username, password,role;



    public User(String username,String password, String role){

        this.username = username;
        this.password = password;
        this.role = role;
    }


}