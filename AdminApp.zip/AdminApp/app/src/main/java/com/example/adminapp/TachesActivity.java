package com.example.adminapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

    public class TachesActivity extends AppCompatActivity {

        ListView listView;
        MyAdapterTache adapter;
        public static ArrayList<Tache> tacheArrayList = new ArrayList<>();
        String url = "https://pbe.diamond-montres.com/android/GetTaches.php";
        Tache tache;

        @Override

        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_taches);

            listView = findViewById(R.id.myListView);
            adapter = new MyAdapterTache(this,tacheArrayList);
            listView.setAdapter(adapter);

            GetTaches();

        }

        public void GetTaches() {

            StringRequest request = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            tacheArrayList.clear();
                            try{
                                JSONObject jsonObject = new JSONObject(response);
                                String success = jsonObject.getString("success");
                                JSONArray jsonArray = jsonObject.getJSONArray("data");

                                if(success.equals("1")) {

                                    for(int i=0; i<jsonArray.length();i++) {
                                        JSONObject object = jsonArray.getJSONObject(i);

                                        int id = object.getInt("id");
                                        String datetache = object.getString("date");
                                        String heuredebut = object.getString("heuredebut");
                                        String heurefin = object.getString("heurefin");
                                        int repetitions = object.getInt("repetitions");
                                        String description = object.getString("description");
                                        int idmoniteur = object.getInt("idmoniteur");

                                        tache = new Tache(id, datetache, heuredebut, heurefin, repetitions, description, idmoniteur);
                                        tacheArrayList.add(tache);
                                        adapter.notifyDataSetChanged();
                                    }

                                }

                            }
                            catch(JSONException e) {
                                e.printStackTrace();
                            }



                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(TachesActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });

            RequestQueue requestQueue = Volley.newRequestQueue(TachesActivity.this);
            requestQueue.add(request);

        }

        public void ToAddTache(View view) {
            startActivity(new Intent(getApplicationContext(), AddTachesActivity.class));
            finish();
        }

        public void Back(View view) {
            startActivity(new Intent(getApplicationContext(), AdminDashboardActivity.class));
            finish();
        }



    }