package com.example.adminapp;

public class Tache {
    private int id_Tache;
    private String dateTache;
    private String heureDebut;
    private String heureFin;
    private int nbrRepetitions;
    private String Description;
    private int id_Moniteur;

    public Tache() {
    }

    public Tache(int id_Tache, String dateTache, String heureDebut, String heureFin, int nbrRepetitions, String description, int id_Moniteur) {
        this.id_Tache = id_Tache;
        this.dateTache = dateTache;
        this.heureDebut = heureDebut;
        this.heureFin = heureFin;
        this.nbrRepetitions = nbrRepetitions;
        Description = description;
        this.id_Moniteur = id_Moniteur;
    }

    public int getId_Tache() {
        return id_Tache;
    }

    public void setId_Tache(int id_Tache) {
        this.id_Tache = id_Tache;
    }

    public String getDateTache() {
        return dateTache;
    }

    public void setDateTache(String dateTache) {
        this.dateTache = dateTache;
    }

    public String getHeureDebut() {
        return heureDebut;
    }

    public void setHeureDebut(String heureDebut) {
        this.heureDebut = heureDebut;
    }

    public String getHeureFin() {
        return heureFin;
    }

    public void setHeureFin(String heureFin) {
        this.heureFin = heureFin;
    }

    public int getNbrRepetitions() {
        return nbrRepetitions;
    }

    public void setNbrRepetitions(int nbrRepetitions) {
        this.nbrRepetitions = nbrRepetitions;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public int getId_Moniteur() {
        return id_Moniteur;
    }

    public void setId_Moniteur(int id_Moniteur) {
        this.id_Moniteur = id_Moniteur;
    }
}
