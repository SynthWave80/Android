package com.example.adminapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class MyAdapterTache extends ArrayAdapter<Tache> {

    Context context;
    List<Tache> arrayListTache;



    public MyAdapterTache(@NonNull Context context, List<Tache> arrayListTache) {
        super(context, R.layout.custom_list_item_tache, arrayListTache);

        this.context = context;
        this.arrayListTache = arrayListTache;

    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_list_item_tache,null,true);


        TextView tvDate = view.findViewById(R.id.txt_date);
        TextView tvDebut = view.findViewById(R.id.txt_debut);
        TextView tvFin = view.findViewById(R.id.txt_fin);
        TextView tvMoniteur = view.findViewById(R.id.txt_idmoniteur);


        tvDate.setText(arrayListTache.get(position).getDateTache());
        tvDebut.setText(arrayListTache.get(position).getHeureDebut());
        tvFin.setText(arrayListTache.get(position).getHeureFin());
        tvMoniteur.setText(String.valueOf(arrayListTache.get(position).getId_Moniteur()));


        return view;
    }
}

