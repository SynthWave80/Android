package com.example.projetequit;

import android.content.Context;
import android.content.SharedPreferences;

public class UserLocalStore {

    public static final String SP_NAME = "UserDetails";
    SharedPreferences UserLocalDatabase;

    public UserLocalStore(Context context) {
        UserLocalDatabase = context.getSharedPreferences(SP_NAME,0);
    }

    public void StoreUserData(User user) {
        SharedPreferences.Editor spEditor = UserLocalDatabase.edit();
        spEditor.putString("name", user.name);
        spEditor.putString("username", user.username);
        spEditor.putString("password", user.password);
        spEditor.putInt("age", user.age);
        spEditor.commit();
    }

    public User getLoggedInUser() {
        String name = UserLocalDatabase.getString("name", "");
        String username = UserLocalDatabase.getString("username", "");
        String password = UserLocalDatabase.getString("password", "");
        int age = UserLocalDatabase.getInt("age", -1);

        User storedUser = new User(name, username, password, age);

        return storedUser;
    }

    public void setUserLoggedIn(boolean loggedIn) {
        SharedPreferences.Editor spEditor = UserLocalDatabase.edit();
        spEditor.putBoolean("LoggedIn", loggedIn);
        spEditor.commit();
    }

    public void ClearUserData() {
        SharedPreferences.Editor spEditor = UserLocalDatabase.edit();
        spEditor.clear();
        spEditor.commit();

    }

    public boolean getUserLoggedIn(){
        if(UserLocalDatabase.getBoolean("LoggedIn", false)== true)
            return true;
        else
            return false;
        }
    }

















